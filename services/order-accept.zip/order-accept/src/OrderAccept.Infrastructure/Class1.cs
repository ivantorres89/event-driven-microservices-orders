﻿namespace OrderAccept.Infrastructure
{
    public class Class1
    {

    }
}
