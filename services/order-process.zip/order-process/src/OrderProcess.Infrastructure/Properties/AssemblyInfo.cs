using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("OrderProcess.UnitTests")]
