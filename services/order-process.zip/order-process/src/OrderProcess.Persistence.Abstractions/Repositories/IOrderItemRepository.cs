using OrderProcess.Persistence.Abstractions.Entities;

namespace OrderProcess.Persistence.Abstractions.Repositories;

public interface IOrderItemRepository : IBaseRepository<OrderItem>
{
}
